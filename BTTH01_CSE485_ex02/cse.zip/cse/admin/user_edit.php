<?php
if(isset($_GET['id'])){
    $uid = $_GET['id'];
    $sql = "SELECT * FROM users WHERE id = '$uid'";

    //Hiển thị FORM chứa thông tin dữ liệu đổ ra từ kết quả trên
    //Lấy thông tin từ FORM và lưu lại
    $sql_update = "UPDATE users SET a=b, x=y WHERE id = '$id'";
}