<div class="col-md-3 sidebar">
    <div class="logo p-2">
        <img src="../images/logo.png" alt="" class="img-fluid">
    </div>
    <div class="navigation">
        <nav class="navbar">
            <div class="container-fluid">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_management.php">User Management</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="category_management.php">Category Management</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>