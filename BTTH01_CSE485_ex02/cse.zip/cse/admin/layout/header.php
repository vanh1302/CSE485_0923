<div class="header d-flex justify-content-between align-items-center">
    <i class="bi bi-list fs-1"></i>
    <span class="h1" style="font-family: 'Poppins', sans-serif;">Dashboard</span>
    <form action="">
        <div class="input-group flex-nowrap">
            <span class="input-group-text"><i class="bi bi-search"></i></span>
            <input type="text" class="form-control" placeholder="Search here ...">
        </div>
    </form>
</div>